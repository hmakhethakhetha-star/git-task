from django.test import TestCase
from django.urls import reverse
from .models import StickyNote

class StickyNoteTests(TestCase):
    def setUp(self):
        self.note = StickyNote.objects.create(
            title="Test Note",
            content="This is a test note."
        )

    def test_create_note(self):
        response = self.client.post(reverse('note_create'), {
            'title': 'New Note',
            'content': 'New content'
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(StickyNote.objects.count(), 2)

    def test_view_notes(self):
        response = self.client.get(reverse('note_list'))
        self.assertContains(response, self.note.title)

    def test_update_note(self):
        response = self.client.post(reverse('note_update', args=[self.note.id]), {
            'title': 'Updated Title',
            'content': 'Updated content'
        })
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Title')

    def test_delete_note(self):
        response = self.client.post(reverse('note_delete', args=[self.note.id]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(StickyNote.objects.filter(id=self.note.id).exists())

    def test_str_method(self):
        self.assertEqual(str(self.note), "Test Note")

