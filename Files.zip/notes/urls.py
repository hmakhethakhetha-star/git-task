from django.urls import path
from . import views

urlpatterns = [
    # CRUD URLs for StickyNote
    # List all notes
    path('', views.note_list, name='note_list'),
    # Create a new note
    path('create/', views.note_create, name='note_create'),
    # Update an existing note
    path('update/<int:pk>/', views.note_update, name='note_update'),
    # Delete an existing note
    path('delete/<int:pk>/', views.note_delete, name='note_delete'),
]
